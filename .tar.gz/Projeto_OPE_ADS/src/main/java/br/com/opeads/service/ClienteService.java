package br.com.opeads.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.opeads.model.Cliente;
import br.com.opeads.repository.ClientePFRepository;
import br.com.opeads.repository.ClientePJRepository;
import br.com.opeads.repository.ClienteRepository;
import br.com.opeads.repository.ContatoRepository;
import br.com.opeads.repository.EnderecoRepository;
import br.com.opeads.service.genericinterfaceservice.GenericInterfaceService;

@Service
public class ClienteService implements GenericInterfaceService<Cliente>{

	private static final long serialVersionUID = -2564111722295953590L;
	
	@Autowired
	private ClienteRepository clienteRepository;
	
	@Autowired
	private ClientePFRepository clientePF;
	
	@Autowired
	private ClientePJRepository clientePJ;
	
	@Autowired
	private ContatoRepository contato;
	
	@Autowired
	private EnderecoRepository endereco;

	@Override
	public List<Cliente> listar() {
		return clienteRepository.findAll();
	}

	@Override
	public void inserir(Cliente cliente) {
		//Cliente check;
		
		clienteRepository.save(cliente);
	}

	@Override
	public void alterar(Cliente  cliente) {
		clienteRepository.save(cliente);
	}

	@Override
	public void remover(Cliente  cliente) {
		clienteRepository.delete(cliente);
	}

	@Override
	public Cliente listarPorId(Cliente  cliente) {
		return clienteRepository.findOne(cliente.getId());
	}


}
